package com.ssolution.core.constant;

public class EndPoint {

	public static final String UPLOAD_PHONE_IMAGE = "uploadphoneimage";
	
	public static final String UPLOAD_PHONE_COLOR_IMAGE = "uploadphonecolorimage";
	
	public static final String UPLOAD_BANNER_IMAGE = "uploadbnrimage";
}
