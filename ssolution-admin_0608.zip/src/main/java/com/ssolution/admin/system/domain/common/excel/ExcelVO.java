package com.ssolution.admin.system.domain.common.excel;

import lombok.Data;

@Data
public class ExcelVO {

	private String head;
	
	private String data;
	
	private String fileName;
}
